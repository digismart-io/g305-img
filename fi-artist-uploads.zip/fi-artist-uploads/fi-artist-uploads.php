<?php
/**
 * Plugin Name: Forsaken Ink — Artist Photo Uploads
 * Description: Shop owner uploads tattoo photos from a simple front-end page (login only, no wp-admin). Each photo is tagged to an artist and appears in that artist's gallery AND the homepage "Recent Work" automatically.
 * Version: 1.2
 * Author: DigiSmart
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class FIAU {
	const TAX       = 'fi_artist';
	const PENDING   = '_fiau_pending';
	const SEEDED    = 'fiau_seeded_v1';
	const APPROVAL  = 'fiau_require_approval'; // '1' = uploads need approval before showing
	const ROLE      = 'fi_uploader';

	/** slug => [name, profile page id, seed attachment ids to tag on first run] */
	static function artists() {
		return array(
			'jamie' => array( 'name' => 'Jamie Henderson', 'page' => 43893, 'seed' => range( 43868, 43879 ) ),
			'jeff'  => array( 'name' => 'Jeff Schick',     'page' => 43996, 'seed' => range( 43983, 43994 ) ),
			'jakub' => array( 'name' => 'Jakub Nadrowski', 'page' => 43973, 'seed' => range( 43960, 43971 ) ),
		);
	}

	static function boot() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'init', array( __CLASS__, 'seed_once' ), 20 );
		add_action( 'init', array( __CLASS__, 'ensure_role' ) );
		add_shortcode( 'fi_artist_gallery', array( __CLASS__, 'sc_artist_gallery' ) );
		add_shortcode( 'fi_recent_work',   array( __CLASS__, 'sc_recent_work' ) );
		add_shortcode( 'fi_upload',         array( __CLASS__, 'sc_upload' ) );
		add_action( 'rest_api_init',        array( __CLASS__, 'rest' ) );
		// Keep the uploader out of wp-admin — send them to the upload page.
		add_action( 'admin_init', array( __CLASS__, 'kick_uploader' ) );
	}

	/* ---------- taxonomy + terms ---------- */
	static function register() {
		register_taxonomy( self::TAX, 'attachment', array(
			'public'       => false,
			'show_ui'      => true,
			'show_admin_column' => true,
			'hierarchical' => false,
			'labels'       => array( 'name' => 'Artists', 'singular_name' => 'Artist' ),
			'rewrite'      => false,
		) );
		foreach ( self::artists() as $slug => $a ) {
			if ( ! term_exists( $slug, self::TAX ) ) {
				wp_insert_term( $a['name'], self::TAX, array( 'slug' => $slug ) );
			}
		}
	}

	/** One-time: tag the existing hard-coded gallery images with their artist. */
	static function seed_once() {
		if ( get_option( self::SEEDED ) ) { return; }
		foreach ( self::artists() as $slug => $a ) {
			foreach ( $a['seed'] as $id ) {
				if ( get_post( $id ) ) { wp_set_object_terms( $id, $slug, self::TAX, true ); }
			}
		}
		update_option( self::SEEDED, 1 );
	}

	/* ---------- role ---------- */
	static function ensure_role() {
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, 'Photo Uploader', array( 'read' => true, 'upload_files' => true ) );
		}
	}
	static function is_uploader_only() {
		$u = wp_get_current_user();
		return $u && in_array( self::ROLE, (array) $u->roles, true ) && ! current_user_can( 'edit_posts' );
	}
	static function kick_uploader() {
		if ( self::is_uploader_only() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
			wp_safe_redirect( home_url( '/add-photos/' ) );
			exit;
		}
	}

	/* ---------- data ---------- */
	static function require_approval() { return get_option( self::APPROVAL ) === '1'; }

	/** Attachment IDs for an artist (or all), newest first; excludes pending when approval is on. */
	static function ids( $artist = '', $limit = -1 ) {
		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);
		if ( $artist ) {
			$args['tax_query'] = array( array( 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => $artist ) );
		} else {
			$args['tax_query'] = array( array( 'taxonomy' => self::TAX, 'operator' => 'EXISTS' ) );
		}
		if ( self::require_approval() ) {
			$args['meta_query'] = array( array( 'key' => self::PENDING, 'compare' => 'NOT EXISTS' ) );
		}
		return get_posts( $args );
	}

	static function artist_of( $id ) {
		$t = wp_get_object_terms( $id, self::TAX, array( 'fields' => 'slugs' ) );
		return $t && ! is_wp_error( $t ) ? $t[0] : '';
	}

	/* ---------- shortcodes: galleries ---------- */
	/** [fi_artist_gallery artist="jamie"] — renders that artist's gallery with the existing look + lightbox. */
	static function sc_artist_gallery( $atts ) {
		$a   = shortcode_atts( array( 'artist' => '', 'columns' => '3' ), $atts );
		$ids = self::ids( $a['artist'] );
		if ( ! $ids ) { return ''; }
		return do_shortcode( '[gallery ids="' . implode( ',', array_map( 'intval', $ids ) ) . '" columns="' . intval( $a['columns'] ) . '" size="full" link="none"]' );
	}

	/** [fi_recent_work count="9"] — homepage Recent Work: newest tagged photos, hover shows the artist, click opens that artist's gallery in a lightbox. */
	static function sc_recent_work( $atts ) {
		$a = shortcode_atts( array( 'count' => '9', 'per_artist' => '' ), $atts );
		if ( $a['per_artist'] !== '' ) {
			$per   = max( 1, intval( $a['per_artist'] ) );
			$lists = array();
			foreach ( array_keys( self::artists() ) as $slug ) { $lists[] = self::ids( $slug, $per ); }
			$ids = array();
			for ( $k = 0; $k < $per; $k++ ) {
				foreach ( $lists as $list ) { if ( isset( $list[ $k ] ) ) { $ids[] = $list[ $k ]; } }
			}
		} else {
			$ids = self::ids( '', intval( $a['count'] ) );
		}
		if ( ! $ids ) { return ''; }
		$artists = self::artists();

		// dynamic artist data for the lightbox: name, profile url, full image list
		$data = array();
		foreach ( $artists as $slug => $info ) {
			$imgs = array();
			foreach ( self::ids( $slug ) as $gid ) {
				$u = wp_get_attachment_image_url( $gid, 'full' );
				if ( $u ) { $imgs[] = $u; }
			}
			$data[ $slug ] = array( 'name' => $info['name'], 'url' => get_permalink( $info['page'] ), 'imgs' => $imgs );
		}

		ob_start(); ?>
<style>
.fi-rw{columns:3;column-gap:30px;width:100%}
.fi-gcell{position:relative;display:block;overflow:hidden;border-radius:25px;margin:0 0 30px;break-inside:avoid;line-height:0;cursor:zoom-in}
.fi-gimg{width:100%;height:auto;display:block;transition:transform .55s ease}
.fi-gcell:hover .fi-gimg{transform:scale(1.08)}
.fi-gname{position:absolute;left:0;right:0;bottom:0;padding:34px 20px 16px;font-family:'Instrument Serif',Georgia,serif;font-size:27px;line-height:1;text-align:center;color:#f8d38d;background:linear-gradient(to top,rgba(4,13,19,.92),rgba(4,13,19,0));opacity:0;transform:translateY(10px);transition:opacity .35s ease,transform .35s ease;pointer-events:none}
.fi-gcell:hover .fi-gname{opacity:1;transform:translateY(0)}
.fi-lbh-cap{position:fixed;left:50%;top:26px;transform:translateX(-50%);z-index:100000;font-family:'Instrument Serif',Georgia,serif;font-size:22px;color:#f8d38d;text-decoration:none;background:rgba(18,54,70,.9);border:2px solid #f8d38d;border-radius:65px;padding:10px 28px;white-space:nowrap;transition:background .2s,color .2s}
.fi-lbh-cap:hover{background:#f8d38d;color:#123646}
#fi-lb-home{display:none;position:fixed;inset:0;z-index:99999;background:rgba(4,13,19,0.95);align-items:center;justify-content:center;padding:40px;box-sizing:border-box}
#fi-lb-home.open{display:flex}
#fi-lb-home #fi-lbh-img{max-width:90vw;max-height:88vh;object-fit:contain;border-radius:6px;box-shadow:0 24px 70px rgba(0,0,0,.6)}
#fi-lb-home .fi-lb-close,#fi-lb-home .fi-lb-prev,#fi-lb-home .fi-lb-next{position:fixed;background:rgba(18,54,70,0.85);border:2px solid #f8d38d;color:#f8d38d;cursor:pointer;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:0;border-radius:50%}
#fi-lb-home .fi-lb-close{top:24px;right:24px;width:48px;height:48px;font-size:26px}
#fi-lb-home .fi-lb-prev,#fi-lb-home .fi-lb-next{top:50%;transform:translateY(-50%);width:56px;height:56px;font-size:28px}
#fi-lb-home .fi-lb-prev{left:24px}#fi-lb-home .fi-lb-next{right:24px}
@media(max-width:782px){.fi-rw{columns:2;column-gap:16px}.fi-gcell{margin:0 0 16px}.fi-gname{opacity:1;transform:none;font-size:21px;text-align:center;padding:24px 14px 12px}.fi-lbh-cap{font-size:17px;top:16px;padding:8px 20px}}
</style>
<div class="fi-rw">
<?php foreach ( $ids as $id ) :
	$slug = self::artist_of( $id );
	$nm   = isset( $artists[ $slug ] ) ? $artists[ $slug ]['name'] : '';
	$src  = wp_get_attachment_image_url( $id, 'large' ); ?>
	<div class="fi-gcell" data-artist="<?php echo esc_attr( $slug ); ?>"><img class="fi-gimg" src="<?php echo esc_url( $src ); ?>" alt="Tattoo by <?php echo esc_attr( $nm ); ?>" loading="lazy"><?php if ( $nm ) : ?><span class="fi-gname"><?php echo esc_html( $nm ); ?></span><?php endif; ?></div>
<?php endforeach; ?>
</div>
<div class="fi-lb-overlay" id="fi-lb-home">
	<button type="button" class="fi-lb-close" id="fi-lbh-close" aria-label="Close">&times;</button>
	<button type="button" class="fi-lb-prev" id="fi-lbh-prev" aria-label="Previous image">&lsaquo;</button>
	<div class="fi-lb-img-wrap"><img id="fi-lbh-img" src="" alt=""></div>
	<button type="button" class="fi-lb-next" id="fi-lbh-next" aria-label="Next image">&rsaquo;</button>
</div>
<script>
(function(){
	var A=<?php echo wp_json_encode( $data ); ?>;
	var ov=document.getElementById('fi-lb-home'),im=document.getElementById('fi-lbh-img');if(!ov||!im)return;
	var cap=document.createElement('a');cap.id='fi-lbh-cap';cap.className='fi-lbh-cap';cap.href='#';ov.appendChild(cap);
	var cur=null,i=0;
	function show(n){var d=A[cur];if(!d||!d.imgs.length)return;i=(n+d.imgs.length)%d.imgs.length;im.src=d.imgs[i];im.alt=d.name+' tattoo';cap.textContent='View '+d.name+' gallery';cap.href=d.url;ov.classList.add('open');document.body.style.overflow='hidden';}
	function hide(){ov.classList.remove('open');document.body.style.overflow='';}
	[].slice.call(document.querySelectorAll('.fi-rw .fi-gcell')).forEach(function(c){c.addEventListener('click',function(){var a=c.getAttribute('data-artist');if(A[a]){cur=a;show(0);}});});
	document.getElementById('fi-lbh-close').addEventListener('click',function(e){e.stopPropagation();hide();});
	document.getElementById('fi-lbh-prev').addEventListener('click',function(e){e.stopPropagation();show(i-1);});
	document.getElementById('fi-lbh-next').addEventListener('click',function(e){e.stopPropagation();show(i+1);});
	im.addEventListener('click',function(e){e.stopPropagation();});
	cap.addEventListener('click',function(e){e.stopPropagation();});
	ov.addEventListener('click',hide);
	document.addEventListener('keydown',function(e){if(!ov.classList.contains('open'))return;if(e.key==='Escape')hide();else if(e.key==='ArrowLeft')show(i-1);else if(e.key==='ArrowRight')show(i+1);});
})();
</script>
<?php
		return ob_get_clean();
	}

	/* ---------- shortcode: upload page ---------- */
	static function sc_upload( $atts ) {
		if ( ! is_user_logged_in() ) {
			return '<div style="max-width:520px;margin:60px auto;text-align:center;color:#f8d38d;font-family:Nunito Sans,sans-serif;">Please <a href="' . esc_url( wp_login_url( home_url( '/add-photos/' ) ) ) . '" style="color:#f8d38d;">log in</a> to add photos.</div>';
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return '<p style="text-align:center;color:#f8d38d;">You do not have permission to upload.</p>';
		}
		$opts = '';
		foreach ( self::artists() as $slug => $a ) {
			$opts .= '<option value="' . esc_attr( $slug ) . '">' . esc_html( $a['name'] ) . '</option>';
		}
		$nonce = wp_create_nonce( 'wp_rest' );
		$url   = esc_url( rest_url( 'fiau/v1/upload' ) );
		ob_start(); ?>
<style>
.fiau-wrap{max-width:560px;margin:40px auto;padding:0 16px;font-family:'Nunito Sans',sans-serif;color:#fff}
.fiau-card{background:#123646;border:1px solid #5f90a5;border-radius:24px;padding:30px}
.fiau-wrap h2{font-family:'Instrument Serif',serif;color:#f8d38d;font-weight:400;font-size:34px;margin:0 0 6px;text-align:center}
.fiau-wrap p.sub{color:#cfe0e7;text-align:center;margin:0 0 22px}
.fiau-field{margin:0 0 16px}
.fiau-field label{display:block;font-weight:700;color:#f8d38d;margin:0 0 6px}
.fiau-wrap select,.fiau-drop{width:100%;box-sizing:border-box}
.fiau-wrap select{padding:12px;border-radius:12px;border:1px solid #5f90a5;background:#0b1f29;color:#fff;font:inherit}
.fiau-drop{border:2px dashed #5f90a5;border-radius:16px;padding:26px;text-align:center;color:#cfe0e7;cursor:pointer}
.fiau-drop.drag{border-color:#f8d38d;background:rgba(248,211,141,.06)}
.fiau-thumbs{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.fiau-thumbs img{width:72px;height:72px;object-fit:cover;border-radius:8px}
.fiau-btn{display:block;width:100%;margin-top:18px;padding:14px;border:0;border-radius:65px;background:#f8d38d;color:#123646;font-weight:800;font-size:16px;letter-spacing:1px;text-transform:uppercase;cursor:pointer}
.fiau-btn[disabled]{opacity:.5;cursor:default}
.fiau-msg{margin-top:14px;text-align:center;min-height:22px}
.fiau-msg.ok{color:#7bd88f}.fiau-msg.err{color:#ff8a8a}
</style>
<div class="fiau-wrap">
	<div class="fiau-card">
		<h2>Add photos</h2>
		<p class="sub">Pick the artist, choose photos, and they go straight to that artist's gallery and the homepage.</p>
		<form id="fiau-form">
			<div class="fiau-field">
				<label for="fiau-artist">Artist</label>
				<select id="fiau-artist" required><?php echo $opts; ?></select>
			</div>
			<div class="fiau-field">
				<label>Photos</label>
				<div class="fiau-drop" id="fiau-drop">Tap to choose photos, or drag them here</div>
				<input type="file" id="fiau-file" accept="image/jpeg,image/png,image/webp" multiple style="display:none">
				<div class="fiau-thumbs" id="fiau-thumbs"></div>
			</div>
			<button type="submit" class="fiau-btn" id="fiau-submit" disabled>Upload</button>
			<div class="fiau-msg" id="fiau-msg"></div>
		</form>
	</div>
</div>
<script>
(function(){
	var REST=<?php echo wp_json_encode( $url ); ?>, NONCE=<?php echo wp_json_encode( $nonce ); ?>;
	var drop=document.getElementById('fiau-drop'),file=document.getElementById('fiau-file'),
	    thumbs=document.getElementById('fiau-thumbs'),submit=document.getElementById('fiau-submit'),
	    msg=document.getElementById('fiau-msg'),form=document.getElementById('fiau-form'),artist=document.getElementById('fiau-artist');
	var files=[];
	function refresh(){thumbs.innerHTML='';files.forEach(function(f){var img=document.createElement('img');img.src=URL.createObjectURL(f);thumbs.appendChild(img);});submit.disabled=!files.length;}
	drop.addEventListener('click',function(){file.click();});
	file.addEventListener('change',function(){files=files.concat([].slice.call(file.files));refresh();file.value='';});
	['dragover','dragenter'].forEach(function(e){drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.add('drag');});});
	['dragleave','drop'].forEach(function(e){drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.remove('drag');});});
	drop.addEventListener('drop',function(ev){files=files.concat([].slice.call(ev.dataTransfer.files).filter(function(f){return /^image\//.test(f.type);}));refresh();});
	form.addEventListener('submit',function(e){
		e.preventDefault();if(!files.length)return;
		submit.disabled=true;msg.className='fiau-msg';msg.textContent='Uploading…';
		var done=0,fail=0,total=files.length;
		files.forEach(function(f){
			var fd=new FormData();fd.append('file',f);fd.append('artist',artist.value);
			fetch(REST,{method:'POST',headers:{'X-WP-Nonce':NONCE},body:fd}).then(function(r){return r.json();}).then(function(d){
				if(d&&d.id){done++;}else{fail++;}
			}).catch(function(){fail++;}).finally(function(){
				if(done+fail===total){
					if(fail){msg.className='fiau-msg err';msg.textContent=done+' uploaded, '+fail+' failed. Try again.';}
					else{msg.className='fiau-msg ok';msg.textContent=done+' photo'+(done===1?'':'s')+' added to '+artist.options[artist.selectedIndex].text+'.';}
					files=[];refresh();submit.disabled=false;
				}
			});
		});
	});
})();
</script>
<?php
		return ob_get_clean();
	}

	/* ---------- REST upload endpoint ---------- */
	static function rest() {
		register_rest_route( 'fiau/v1', '/upload', array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'upload_files' ); },
			'callback'            => array( __CLASS__, 'handle_upload' ),
		) );
		register_rest_route( 'fiau/v1', '/approve', array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'edit_posts' ); },
			'callback'            => array( __CLASS__, 'handle_approve' ),
		) );
	}

	static function handle_upload( $req ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$artist = sanitize_key( $req->get_param( 'artist' ) );
		if ( ! array_key_exists( $artist, self::artists() ) ) {
			return new WP_Error( 'bad_artist', 'Unknown artist', array( 'status' => 400 ) );
		}
		$files = $req->get_file_params();
		if ( empty( $files['file'] ) ) {
			return new WP_Error( 'no_file', 'No file', array( 'status' => 400 ) );
		}
		$f = $files['file'];
		$allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
		if ( ! in_array( $f['type'], $allowed, true ) || $f['size'] > 25 * 1024 * 1024 ) {
			return new WP_Error( 'bad_file', 'Images only, up to 25MB', array( 'status' => 400 ) );
		}
		$_FILES = array( 'file' => $f );
		$id = media_handle_upload( 'file', 0 );
		if ( is_wp_error( $id ) ) { return $id; }
		wp_set_object_terms( $id, $artist, self::TAX, true );
		if ( self::require_approval() ) { update_post_meta( $id, self::PENDING, 1 ); }
		return array( 'id' => (int) $id );
	}

	static function handle_approve( $req ) {
		$id = (int) $req->get_param( 'id' );
		if ( $id ) { delete_post_meta( $id, self::PENDING ); }
		return array( 'ok' => true );
	}
}
FIAU::boot();
